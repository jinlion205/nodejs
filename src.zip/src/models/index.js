module.exports.Token = require('./token.model');
module.exports.User = require('./user.model');
module.exports.Thai = require('./thai.model');
module.exports.Lop = require('./lop.model');
module.exports.Sinhvien = require('./sinhvien.model');
